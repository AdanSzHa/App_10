package com.adans.tryreturn;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.hardware.Sensor;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements SensorEventListener,LocationListener{


    private TextView Gx,Gy,Gz,Ax,Ay,Az;

    Button btnMostrar;

    private Handler mHandler = new Handler();

    //////
    Button getLocationBtn;
    TextView locationText;

    LocationManager locationManager;
    //////


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Ax= (TextView) findViewById(R.id.tvAx);
        Ay= (TextView) findViewById(R.id.tvAy);
        Az= (TextView) findViewById(R.id.tvAz);

        Gx= (TextView) findViewById(R.id.tvGx);
        Gy= (TextView) findViewById(R.id.tvGy);
        Gz= (TextView) findViewById(R.id.tvGz);


        btnMostrar=(Button)findViewById(R.id.btnMostrar);


        SensorManager sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        List<Sensor> listaSensores = sensorManager.getSensorList(Sensor.TYPE_ALL);


        listaSensores = sensorManager.getSensorList(Sensor.TYPE_ACCELEROMETER);

        if (!listaSensores.isEmpty()) {
            Sensor acelerometerSensor = listaSensores.get(0);
            sensorManager.registerListener(this, acelerometerSensor,
                    SensorManager.SENSOR_DELAY_NORMAL);}

        listaSensores = sensorManager.getSensorList(Sensor.TYPE_GYROSCOPE);

        if (!listaSensores.isEmpty()) {
            Sensor giroscopioSensor = listaSensores.get(0);
            sensorManager.registerListener(this, giroscopioSensor,
                    SensorManager.SENSOR_DELAY_NORMAL);}


        btnMostrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mostrarCursos= new Intent(getApplicationContext(),Cursos.class);
                startActivity(mostrarCursos);
            }
        });

    /////////////
        getLocationBtn = (Button)findViewById(R.id.btnStart);
        locationText = (TextView)findViewById(R.id.tvLoc);


        if (ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION}, 101);

        }


        getLocationBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getLocation();
            }
        });

        ////////////

    }

    void getLocation() {
        try {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 1, this);
        }
        catch(SecurityException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onSensorChanged(SensorEvent event) {
        synchronized (this) {
            switch(event.sensor.getType()) {

                case Sensor.TYPE_ACCELEROMETER:

                    this.Ax.setText("AX ="+event.values[0]);
                    this.Ay.setText("AY ="+event.values[1]);
                    this.Az.setText("AZ ="+event.values[2]);

                    break;
                case Sensor.TYPE_GYROSCOPE:

                    this.Gx.setText("GX ="+event.values[0]);
                    this.Gy.setText("GY ="+event.values[1]);
                    this.Gz.setText("GZ ="+event.values[2]);
                    break;
            }
        }
    }


    public void startRepeating(View v) {
        //mHandler.postDelayed(mToastRunnable, 5000);
        mToastRunnable.run();
    }

    public void stopRepeating(View v) {
        mHandler.removeCallbacks(mToastRunnable);
    }

    private Runnable mToastRunnable = new Runnable() {
        @Override
        public void run() {

            final MantBDD mantBDD=new MantBDD(getApplicationContext());

            mantBDD.agregarCurso(Ax.getText().toString(),Ay.getText().toString(),Az.getText().toString(),Gx.getText().toString(),Gy.getText().toString(),Gz.getText().toString());

            //  Toast.makeText(getApplicationContext(),"Se agregaron correctamente",Toast.LENGTH_SHORT).show();
            int dly=3;//Segundos
            Toast.makeText(MainActivity.this, "Guardando Datos, Cada "+dly+" Segundos", Toast.LENGTH_SHORT).show();
            mHandler.postDelayed(this, dly*1000);
        }
    };

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}




    @Override
    public void onLocationChanged(Location location) {

        locationText.setText("Latitude: " + location.getLatitude() + "\n Longitude: " + location.getLongitude());

        //try {
        //    Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        //    List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
        //    locationText.setText(locationText.getText() + "\n"+addresses.get(0).getAddressLine(0)+", "+
        //            addresses.get(0).getAddressLine(1)+", "+addresses.get(0).getAddressLine(2));
        //}catch(Exception e) { }

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

        Toast.makeText(MainActivity.this, "Please Enable GPS and Internet", Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
}